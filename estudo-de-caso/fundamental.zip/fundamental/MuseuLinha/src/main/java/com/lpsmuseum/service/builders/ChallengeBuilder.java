package com.lpsmuseum.service.builders;

import java.util.ArrayList;
import java.util.List;

import com.lpsmuseum.dto.scenario.AbstractChallengeItem;

public class ChallengeBuilder<T> {
	private List<AbstractChallengeItem<T>> items = new ArrayList<AbstractChallengeItem<T>>();

}
