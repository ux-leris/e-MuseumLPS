package com.lpsmuseum.behaviour.object;

public interface ImageVisualization {
	void getVisualization();
}
