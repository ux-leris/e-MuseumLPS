package com.lpsmuseum.behaviour.object.impl;

import com.lpsmuseum.behaviour.object.ImageVisualization;

public class DetailedVisualization implements ImageVisualization {

	public void getVisualization() {
		// TODO Auto-generated method stub
	}

}
