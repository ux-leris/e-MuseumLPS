package com.lpsmuseum.behaviour.object.impl;

import com.lpsmuseum.behaviour.object.ImageVisualization;

public class PerspectiveVisualization implements ImageVisualization {

	public void getVisualization() {
		// TODO Auto-generated method stub

	}

}
