package com.lpsmuseum;

import com.lpsmuseum.service.ScenarioService;

public class Main {

	public static void main(String[] args) {
		new ScenarioService().listScenarios();
	}

}
