# IHC_PDS-WebMuseu-Producao
Instrução:

Rode o arquivo SQL-DADOS.sql em um SGBD mysql, antes de executar o projeto pela primeira vez.
Arquivo de LPS nao está incluso no repositório necessário obtê-lo por outros meios.

# Links para Acompanhamento

Kanban-chi: https://kanban-chi.appspot.com/dashboard/4583867504656384/d-4583867504656384

Site/blog da fábrica: http://filipesrocchi.wix.com/ncsoftwares

