package com.lpsmuseum.behaviour.museum.navigation;

public class Graph {

}
