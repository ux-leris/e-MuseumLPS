package com.lpsmuseum.behaviour.object.impl;

import com.lpsmuseum.behaviour.object.Indexation;

public class AutomaticIndexation extends Indexation {

}
