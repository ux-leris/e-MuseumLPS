package com.lpsmuseum.behaviour.object;

import java.util.List;

public class Indexation {
	private int idIndex;
	private List<String> words;
	
	public void getIndex(){
		
	}

	public int getIdIndexation() {
		return idIndex;
	}

	public void setIdIndexation(int idIndex) {
		this.idIndex = idIndex;
	}

	public List<String> getWords() {
		return words;
	}

	public void setWords(List<String> words) {
		this.words = words;
	}
}
