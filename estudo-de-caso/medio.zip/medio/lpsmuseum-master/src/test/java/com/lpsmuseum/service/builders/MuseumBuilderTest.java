package com.lpsmuseum.service.builders;

import junit.framework.TestCase;

public class MuseumBuilderTest extends TestCase {

	public void testBuild() {
		fail("Not yet implemented");
	}

}
