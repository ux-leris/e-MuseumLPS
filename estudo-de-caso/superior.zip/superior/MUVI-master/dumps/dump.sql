-- MySQL dump 10.13  Distrib 5.7.11, for Linux (x86_64)
--
-- Host: localhost    Database: lpsmuseumdb
-- ------------------------------------------------------
-- Server version	5.7.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `annotation`
--

DROP TABLE IF EXISTS `annotation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `annotation` (
  `id_annotation` bigint(20) NOT NULL AUTO_INCREMENT,
  `author` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `id_museum` bigint(20) DEFAULT NULL,
  `id_object` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id_annotation`),
  KEY `FK_b5a56479xr9r485xkefh90x02` (`id_museum`),
  KEY `FK_4bk6qed4kk7uf0su9s092k626` (`id_object`),
  CONSTRAINT `FK_4bk6qed4kk7uf0su9s092k626` FOREIGN KEY (`id_object`) REFERENCES `museological_object` (`id_object`),
  CONSTRAINT `FK_b5a56479xr9r485xkefh90x02` FOREIGN KEY (`id_museum`) REFERENCES `museum` (`id_museum`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `annotation`
--

LOCK TABLES `annotation` WRITE;
/*!40000 ALTER TABLE `annotation` DISABLE KEYS */;
/*!40000 ALTER TABLE `annotation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `answer`
--

DROP TABLE IF EXISTS `answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `answer` (
  `DTYPE` varchar(31) NOT NULL,
  `id_answer` bigint(20) NOT NULL AUTO_INCREMENT,
  `correct` bit(1) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_answer`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `answer`
--

LOCK TABLES `answer` WRITE;
/*!40000 ALTER TABLE `answer` DISABLE KEYS */;
INSERT INTO `answer` VALUES ('AnswerDO',1,'','Privada'),('AnswerDO',2,'\0','Religioso'),('AnswerDO',3,'\0','Estatal'),('AnswerDO',4,'','Desenvolvimento social e econômico'),('AnswerDO',5,'\0','Disciplinar a população'),('AnswerDO',6,'\0','Desenvolver senso crítico');
/*!40000 ALTER TABLE `answer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `challenge`
--

DROP TABLE IF EXISTS `challenge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `challenge` (
  `id_challenge` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_challenge`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `challenge`
--

LOCK TABLES `challenge` WRITE;
/*!40000 ALTER TABLE `challenge` DISABLE KEYS */;
INSERT INTO `challenge` VALUES (1,'O substitutivo de Carlos Lacerda atribuía a responsabilidade pela educação a qual esfera? '),(2,'Durante a Ditadura Militar o Estado ajustou o modelo de ensino voltado para: ');
/*!40000 ALTER TABLE `challenge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `challenge_answer`
--

DROP TABLE IF EXISTS `challenge_answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `challenge_answer` (
  `id_challenge` bigint(20) NOT NULL,
  `id_answer` bigint(20) NOT NULL,
  KEY `FK_62pllanja13j1smajhm93hyyu` (`id_answer`),
  KEY `FK_sxa37acu11nk3sdfun3rd4tw5` (`id_challenge`),
  CONSTRAINT `FK_62pllanja13j1smajhm93hyyu` FOREIGN KEY (`id_answer`) REFERENCES `answer` (`id_answer`),
  CONSTRAINT `FK_sxa37acu11nk3sdfun3rd4tw5` FOREIGN KEY (`id_challenge`) REFERENCES `challenge` (`id_challenge`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `challenge_answer`
--

LOCK TABLES `challenge_answer` WRITE;
/*!40000 ALTER TABLE `challenge_answer` DISABLE KEYS */;
INSERT INTO `challenge_answer` VALUES (1,1),(1,2),(1,3),(2,1),(2,2),(2,3);
/*!40000 ALTER TABLE `challenge_answer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `museological_object`
--

DROP TABLE IF EXISTS `museological_object`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `museological_object` (
  `DTYPE` varchar(31) NOT NULL,
  `id_object` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `object_type` bit(1) DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL,
  `urlAddress` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_object`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `museological_object`
--

LOCK TABLES `museological_object` WRITE;
/*!40000 ALTER TABLE `museological_object` DISABLE KEYS */;
INSERT INTO `museological_object` VALUES ('TextDO',1,'2016-03-31','Intro Text','','Instrumento normativo considerado fundamental na definição de um sistema nacional de educação, a Lei de Diretrizes e Bases (LDB) aparece no texto constitucional de 1946 entre as competências legislativas da União,',NULL),('TextDO',2,'2016-03-31','Intro Text','\0',' inserindo-se em um novo arranjo institucional que rompia com o presidencialismo autocrático.',NULL),('ImageDO',3,'2016-03-31','Intro Image',NULL,'','/home/guilhermejcgois/Projects/MUVI/src/main/webapp/resources/img/tema1/intro1.jpg'),('TextDO',4,'2016-04-01','Intro 2 Text','','A tramitação da lei durou 13 anos, expondo a lentidão das duas casas legislativas em decidirem sobre temas de maior importância e complexidade devido a problemas de “acordos interpartidários” feitos para sustentar o Executivo e,',NULL),('TextDO',5,'2016-04-01','Intro 2 Text','\0',' quando aprovada durante a legislatura 1959-1963, acabou instruída pela orientação doutrinária predominante no texto constitucional de 1946.',''),('ImageDO',6,'2016-04-01','Intro 2 Image','\0','','/home/guilhermejcgois/Projects/MUVI/src/main/webapp/resources/img/tema1/intro2.jpg'),('TextDO',7,'2016-03-31','Carlos 1 Text','','A aprovação da LDB era vista como uma possibilidade de regulamentar amplamente a ação da iniciativa privada e das três esferas de governo (União, estados e municípios), auxiliando assim na construção de uma política orgânica.',NULL),('TextDO',13,'2016-04-01','Carlos 1 Text','','O substitutivo de Clóvis Salgado ao anteprojeto da LDB foi referido positivamente pelo professor Almeida Junior, relator-geral do comissão Mariani, este documento visava acelerar o processo de tramitação da lei na Câmara dos Deputados, ',NULL),('TextDO',14,'2016-03-31','Carlos 1 Text','','uma vez que o plano de metas de Juscelino Kubitschek, pouco havia deixado para a educação (3,4% dos investimentos previstos e uma única meta). O empenho do Ministério da Educação com relação à LDB, de certa forma, ',NULL),('TextDO',15,'2016-04-01','Carlos 1 Text','\0','vinha compensar o descaso do Poder Executivo em integrar a educação à política desenvolvimentista, o substitutivo foi bem aceito e ia ser aprovado em 1958 mas Carlos Lacerda levantou-se contra o projeto.',''),('ImageDO',16,'2016-04-01','Carlos 1 Image',NULL,NULL,'/home/guilhermejcgois/Projects/MUVI/src/main/webapp/resources/img/tema1/lacerda1.jpg'),('TextDO',17,'2016-04-01','Carlos 2 Text','','No substitutivo Carlos Lacerda foi vedado ao Estado exercer ou favorecer monopólio do ensino, justificado pela necessidade de promover a “educação democrática”. ',NULL),('TextDO',18,'2016-04-01','Carlos 2 Text','','Em resumo, o pensamento educacional veiculado pelo substituto de Carlos Lacerda e Perilo Teixeira entendia que a responsabilidade pela educação em uma sociedade democrática não caberia ao Estado, e sim aos particulares, ',NULL),('TextDO',19,'2016-04-01','Carlos 2 Text','','sendo a escola uma instância complementar à educação dada pelas famílias. A universalização do ensino e, consequentemente, o rompimento com o dualismo totalitário, ',NULL),('TextDO',20,'2016-04-01','Carlos 2 Text','\0','deveria ocorrer pelo apoio às famílias pobres, que poderiam optar pela escola de seus filhos em um mercado aberto à iniciativa privada.',NULL),('ImageDO',21,'2016-04-01','Carlos 2 Image','\0',NULL,'/home/guilhermejcgois/Projects/MUVI/src/main/webapp/resources/img/tema1/lacerda2.jpg'),('TextDO',22,'2016-04-01','Ditadura 1 Text','','A ordem era elemento importante do binômio doutrinário das políticas pós-1964: desenvolvimento e segurança. Considerava-se que havia motivos para os militares preocuparem-se com a educação, ',NULL),('TextDO',23,'2016-04-01','Ditadura 1 Text','\0','em especial por dentro do Estado, já que de seu interior emanava a abertura e até mesmo o financiamento para o avanço comunista. Os órgãos relativos à educação e até mesmo o cotidiano no ensino escolar receberam atenção ampla do governo militar.',NULL),('ImageDO',24,'2016-04-01','Ditadura 1 Image','\0',NULL,'/home/guilhermejcgois/Projects/MUVI/src/main/webapp/resources/img/tema2/ditadura1.jpg'),('TextDO',25,'2016-04-01','Ditadura 2 Text','','A reestruturação do sistema escolar ocorreu nessa época, com a criação da escola fundamental de 8 anos voltada pra realização de alguma atividade prática, o ensino de 2º grau voltado para o desenvolvimento social e econômico do país e o ',NULL),('TextDO',26,'2016-04-01','Ditadura 2 Text','','ensino superior ficou a cargo de formar mão-de-obra especializada requerida pelas empresas e preparar os quadros dirigentes do país.',NULL),('TextDO',27,'2016-04-01','Ditadura 2 Text','','A atual estrutura de organização educacional, principalmente no ensino superior, mestrado e doutorado remetem a essa época. Também foi durante o período de Ditadura que, por meio do corte de investimentos, foi privilegiada a educação privada.',NULL),('TextDO',28,'2016-04-01','Ditadura 2 Text','\0','Legado do regime militar, a institucionalização da visão produtivista de educação mantém-se como hegemônica, tendo orientado a elaboração da nova LDB, promulgada em 1996, e o Plano Nacional de Educação, aprovado em 2001. ',NULL),('ImageDO',29,'2016-04-01','Ditadura 2 Image','\0',NULL,'/home/guilhermejcgois/Projects/MUVI/src/main/webapp/resources/img/tema2/ditadura2.jpg'),('TextDO',30,'2016-04-01','LDB 96 1 Text','','Organizada em níveis fundamental e médio, a educação básica tem “por finalidades desenvolver o educando, assegurando-lhe a formação comum ',NULL),('TextDO',31,'2016-04-01','LDB 96 1 Text','\0','indispensável para o exercício da cidadania, e fornecer-lhe meios para progredir no trabalho e em estudos posteriores” (Lei no 9.394/96, art. 22).',NULL),('ImageDO',32,'2016-04-01','LDB 96 1 Image','\0',NULL,'/home/guilhermejcgois/Projects/MUVI/src/main/webapp/resources/img/tema3/ldb961.jpg'),('TextDO',33,'2016-04-01','LDB 96 2 Text','','Alimentada pela Constituinte de 1988 e por um amplo movimento da sociedade civil nos anos subsequentes a Nova Lei de Diretrizes e Bases da Educação Nacional é aprovada no Governo de Fernando Henrique Cardoso. ',NULL),('TextDO',34,'2016-04-01','LDB 96 2 Text','','O início da construção do projeto da Nova LDB e do Plano Nacional de Educação se deu devido aos educadores, mediante suas instituições, que experimentaram uma década de debates, ',NULL),('TextDO',35,'2016-04-01','LDB 96 2 Text','\0','na ditadura civil-militar para a redemocratização passando assim, no campo da educação no Brasil, das leis do arbítrio da ditadura civil-militar para a ditadura da ideologia do mercado.',NULL),('ImageDO',36,'2016-04-01','LDB 96 2 Image','\0',NULL,'/home/guilhermejcgois/Projects/MUVI/src/main/webapp/resources/img/tema3/ldb962.jpg'),('TextDO',37,'2016-04-01','LDB 96 3 Text','','No reconhecimento dos problemas maiores do mundo globalizado, sob os quais temos que tomar decisões locais, a educação é ao mesmo tempo determinada e determinante, além de ser crucial para uma formação integral humanística e',NULL),('TextDO',38,'2016-04-01','LDB 96 3 Text','\0',' científica de sujeitos autônomos, críticos, criativos e protagonistas da cidadania ativa, é decisiva, também, para romper com a condição histórica de subalternidade e de resistir a uma completa dependência científica, tecnológica e cultural.',NULL),('ImageDO',39,'2016-04-01','LDB 96 3 Image','\0',NULL,'/home/guilhermejcgois/Projects/MUVI/src/main/webapp/resources/img/tema3/ldb963.jpg'),('MuseologicalObjectDO',40,'2016-03-31','TestObject',NULL,NULL,NULL),('TextDO',41,'2016-03-31','TestText',NULL,NULL,NULL),('ImageDO',42,'2016-03-31','TestImage',NULL,NULL,'http://www.image.com/'),('MuseologicalObjectDO',43,'2016-04-01','Object 1',NULL,NULL,NULL),('ImageDO',44,'2016-04-01','TestImg',NULL,NULL,'http://www.test.com/'),('MuseologicalObjectDO',45,'2016-04-01','TesTObj',NULL,NULL,NULL),('MuseologicalObjectDO',46,'2016-03-31','TestObj',NULL,NULL,NULL),('MuseologicalObjectDO',52,'2016-04-01','Object',NULL,NULL,NULL),('MuseologicalObjectDO',53,'2016-03-31','ObjOld',NULL,NULL,NULL),('ImageDO',54,'2016-04-01','TestMO',NULL,NULL,'http://www.testmuseum.com/');
/*!40000 ALTER TABLE `museological_object` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `museum`
--

DROP TABLE IF EXISTS `museum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `museum` (
  `id_museum` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_museum`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `museum`
--

LOCK TABLES `museum` WRITE;
/*!40000 ALTER TABLE `museum` DISABLE KEYS */;
INSERT INTO `museum` VALUES (1,'Lei de Diretrizes e Bases'),(2,'museum onetest');
/*!40000 ALTER TABLE `museum` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scenario`
--

DROP TABLE IF EXISTS `scenario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scenario` (
  `DTYPE` varchar(31) NOT NULL,
  `id_scenario` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `id_museum` bigint(20) DEFAULT NULL,
  `id_theme` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id_scenario`),
  KEY `FK_1rn40kvfc3g2haavs90ug1h8u` (`id_museum`),
  KEY `FK_dufv0dvjhoiyfpiirc2gc0q9d` (`id_theme`),
  CONSTRAINT `FK_1rn40kvfc3g2haavs90ug1h8u` FOREIGN KEY (`id_museum`) REFERENCES `museum` (`id_museum`),
  CONSTRAINT `FK_dufv0dvjhoiyfpiirc2gc0q9d` FOREIGN KEY (`id_theme`) REFERENCES `theme` (`id_theme`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scenario`
--

LOCK TABLES `scenario` WRITE;
/*!40000 ALTER TABLE `scenario` DISABLE KEYS */;
INSERT INTO `scenario` VALUES ('ScenarioDO',1,'Intro 1/2',1,1),('ScenarioDO',2,'Intro 2/2',1,1),('ScenarioDO',3,'Carlos Lacerda 1/2',1,1),('ScenarioChallengeDO',4,'Carlos Lacerda 2/2',1,1),('ScenarioDO',5,'Ditadura 1/2',1,2),('ScenarioChallengeDO',6,'Ditadura 2/2',1,2),('ScenarioDO',7,'LDB 96 1/2',1,3),('ScenarioDO',8,'LDB 96 2/2',1,3);
/*!40000 ALTER TABLE `scenario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scenario_challenge`
--

DROP TABLE IF EXISTS `scenario_challenge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scenario_challenge` (
  `id_scenario` bigint(20) NOT NULL,
  `id_challenge` bigint(20) NOT NULL,
  KEY `FK_gwsr96kkl8c07w0kvc7xsf1ec` (`id_challenge`),
  KEY `FK_ei0tincbhj9egrgtp2gu9kft3` (`id_scenario`),
  CONSTRAINT `FK_ei0tincbhj9egrgtp2gu9kft3` FOREIGN KEY (`id_scenario`) REFERENCES `scenario` (`id_scenario`),
  CONSTRAINT `FK_gwsr96kkl8c07w0kvc7xsf1ec` FOREIGN KEY (`id_challenge`) REFERENCES `challenge` (`id_challenge`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scenario_challenge`
--

LOCK TABLES `scenario_challenge` WRITE;
/*!40000 ALTER TABLE `scenario_challenge` DISABLE KEYS */;
INSERT INTO `scenario_challenge` VALUES (4,1),(6,2);
/*!40000 ALTER TABLE `scenario_challenge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scenario_object`
--

DROP TABLE IF EXISTS `scenario_object`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scenario_object` (
  `id_scenario` bigint(20) NOT NULL,
  `id_object` bigint(20) NOT NULL,
  KEY `FK_t2s4xameh5wtk18avl48d3y8b` (`id_object`),
  KEY `FK_l4xpybg71faffnkbg9bj7e33y` (`id_scenario`),
  CONSTRAINT `FK_l4xpybg71faffnkbg9bj7e33y` FOREIGN KEY (`id_scenario`) REFERENCES `scenario` (`id_scenario`),
  CONSTRAINT `FK_t2s4xameh5wtk18avl48d3y8b` FOREIGN KEY (`id_object`) REFERENCES `museological_object` (`id_object`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scenario_object`
--

LOCK TABLES `scenario_object` WRITE;
/*!40000 ALTER TABLE `scenario_object` DISABLE KEYS */;
/*!40000 ALTER TABLE `scenario_object` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `theme`
--

DROP TABLE IF EXISTS `theme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `theme` (
  `id_theme` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_theme`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `theme`
--

LOCK TABLES `theme` WRITE;
/*!40000 ALTER TABLE `theme` DISABLE KEYS */;
INSERT INTO `theme` VALUES (1,'Introdução LDB','Introdução LDBtest'),(2,'Ditadura','Ditaduratest'),(3,'LDB 96','LDB 96test'),(4,'Tema teste de um cenário de testes.','Tema teste 1test');
/*!40000 ALTER TABLE `theme` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-04-01 16:16:52
