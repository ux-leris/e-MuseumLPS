package com.lpsmuseum.service.builders;

import junit.framework.TestCase;

public class ScenarioBuilderTest extends TestCase {

	public void testBuild() {
		//fail("Not yet implemented");
	}

}
