/**
 * Interfaces to the features of navigation and sharing.
 * 
 */
package com.lpsmuseum.behaviour.museum;
