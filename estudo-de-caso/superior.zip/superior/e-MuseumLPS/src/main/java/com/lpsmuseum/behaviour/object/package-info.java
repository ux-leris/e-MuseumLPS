/**
 * Classes and interfaces to the features of images visualization and 
 * museological objects indexation.
 * 
 */
package com.lpsmuseum.behaviour.object;
