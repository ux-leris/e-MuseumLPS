package com.lpsmuseum.behaviour.museum.navigation;

/**
 * This class represents a <b>graph</b> of the navigation inside of a museum. 
 * Not implementd yet.
 */
public class Graph {

	/**
	 * Class constructor.
	 */
	public Graph() {
	}
}
