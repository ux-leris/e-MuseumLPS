/**
 * Implementations of the sharing feature.
 * 
 * <p>
 * The possible default sharing available are:
 * <ul>
 * <li>Dropbox
 * </ul>
 */
package com.lpsmuseum.behaviour.museum.share;
