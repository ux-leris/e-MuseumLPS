/**
 * Classes to interact with the database, under the <b>Data Access Object 
 * pattern (DAO)</b>
 */
package com.lpsmuseum.dao;
