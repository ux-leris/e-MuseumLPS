/**
 * Classes for the transfering of objects between client-side and server-side. 
 * These classes are related to <code>Scenario</code>.
 */
package com.lpsmuseum.dto.scenario;
