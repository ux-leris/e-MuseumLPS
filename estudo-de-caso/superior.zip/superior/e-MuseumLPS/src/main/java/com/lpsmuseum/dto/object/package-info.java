/**
 * Classes for the transfering of objects between client-side and server-side. 
 * These classes are related to <code>MuseologicalObject</code>.
 */
package com.lpsmuseum.dto.object;
