/**
 * Classes that provides services to the client application.
 * 
 */
package com.lpsmuseum.service;
