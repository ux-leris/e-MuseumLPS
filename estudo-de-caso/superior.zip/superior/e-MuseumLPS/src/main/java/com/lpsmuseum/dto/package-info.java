/**
 * Classes for the transfering of objects between client-side and server-side.
 */
package com.lpsmuseum.dto;
