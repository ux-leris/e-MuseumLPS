/**
 * Classes based on <b>builder</b> pattern to help in the creation of objects 
 * to be persisted.
 */
package com.lpsmuseum.service.builders;
